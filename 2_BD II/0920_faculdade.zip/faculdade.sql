USE MASTER 
GO

IF EXISTS(SELECT 1 FROM SYSDATABASES WHERE NAME = 'faculdade')
	DROP DATABASE faculdade


CREATE DATABASE faculdade
go
Use faculdade
go
create table tblDepto
(
	codDepto char(8),
	nomeDepto varchar(20),
	primary key (codDepto)
);
insert into tblDepto values ('INF01', 'Inform�tica' );
insert into tblDepto values ('MAT01', 'Matem�tica');
insert into tblDepto values ('ELE01', 'Eletr�nica') ;
go
create table tblDisciplina
(
	codDepto char(8),
	numDisc char(10),
	nomeDisc varchar(20),
	creditosDisc integer ,
	primary key (codDepto, numDisc),
	foreign key (codDepto) references tblDepto );
go	
insert into tblDisciplina values ('INF01','DIS01','Ling Formais', 4);
insert into tblDisciplina values ('INF01','DIS02','Teoria da Comp', 4);
insert into tblDisciplina values ('INF01','DIS03','Programacao I', 8);
insert into tblDisciplina values ('MAT01','DIS04','C�lculo 1', 4);
insert into tblDisciplina values ('MAT01','DIS01','C�lculo 2', 6);
go
create table tblPreReq
(
	codDepto char(8),
	numDisc char(10),
	codDeptoPreReq char(8),
	numDiscPreReq char(10),
	primary key (codDepto, numDisc, codDeptoPreReq, numDiscPreReq),
	foreign key (codDepto, numDisc) references tbldisciplina,
	foreign key (codDeptoPreReq, numDiscPreReq) references tbldisciplina);
go
insert into tblPreReq values ('INF01', 'DIS02', 'INF01', 'DIS01');
insert into tblPreReq values ('MAT01', 'DIS04', 'MAT01', 'DIS01');
insert into tblPreReq values ('INF01', 'DIS03', 'INF01', 'DIS02');
go 
create table tblTurma
(
	anoSem integer ,
	codDepto char(8),
	numDisc char(10),
	siglaTur char(5),
	capacTur integer ,
	primary key (anoSem, codDepto, numDisc, siglaTur),
	foreign key (codDepto, numDisc) references tblDisciplina
)
go
insert into tblturma values (20021, 'INF01', 'DIS01', 'TUR01', 30);
insert into tblturma values (20022, 'INF01', 'DIS01', 'TUR01', 30);
insert into tblturma values (20021, 'INF01', 'DIS02', 'TUR02', 30);
insert into tblturma values (20022, 'INF01', 'DIS03', 'TUR01', 200);
insert into tblturma values (20031, 'INF01', 'DIS03', 'TUR02', 30);
insert into tblturma values (20021, 'MAT01', 'DIS01', 'TUR01', 15);
insert into tblturma values (20022, 'INF01', 'DIS03', 'TUR02', 25);
go
create table tblPredio
(
	codPred integer ,
	nomePred varchar(30),
	primary key (codPred)
)
go
insert into tblpredio values (43423, 'Inform�ti ca-Aulas' );
insert into tblpredio values (43421, 'Administra��o');
insert into tblpredio values (43424, 'Laborat�rios');
go
create table tblSala 
(
	codPred integer ,
	numSala integer,
	capacSala integer ,
	primary key (codPred, numSala),
	foreign key(codPred)references tblPredio
);
go
insert into tblsala values (43423, 101, 30);
insert into tblsala values (43421, 102, 50);
insert into tblsala values (43424, 215, 40);
go
create table tblHorario
(
	anoSem integer ,
	codDepto char(8),
	numDisc char(10),
	siglaTur char(5),
	diaSem integer,
	horaInicio char(5),
	numHoras integer ,
	codPredio integer ,
	numSala integer,
	primary key (anoSem, codDepto, numDisc, siglaTur, diaSem,horaInicio),
	foreign key (anoSem, codDepto, numDisc, siglaTur) references tblturma,
	foreign key (codPredio, numSala) references tblsala
);
go
insert into tblhorario values (20021, 'INF01', 'DIS01', 'TUR01', 2, '10:30', 60, 43423, 101);
insert into tblhorario values (20021, 'INF01', 'DIS02', 'TUR02', 3, '10:30', 60, 43423, 101);
insert into tblhorario values (20022, 'INF01', 'DIS03', 'TUR02', 4, '08:30', 45, 43424, 215);
insert into tblhorario values (20021, 'INF01', 'DIS01', 'TUR01', 4, '13:30', 60, 43423, 101);
go
create table tblTitulacao
(
	codTit integer ,
	nomeTit varchar(20),
	primary key (codTit)
);
go
insert into tblTitulacao values (1, 'Doutor');
insert into tblTitulacao values (2, 'Mestre');
insert into tblTitulacao values (3, 'Especial i sta') ;
insert into tblTitulacao values (4, 'Graduado' )
go
create table tblProfessor
(
	codProf char(5),
	nomeProf varchar(50),
	codTit integer ,
	codDepto char(8),
	primary key (codProf),
	foreign key (codTit) references tblTitulacao,
	foreign key (codDepto) references tblDepto 
);
go
insert into tblProfessor values ('Pro01', 'Antunes', 1, 'INF01');
insert into tblProfessor values ('Pro02', 'Maria dos Santos', 2, 'INF01');
insert into tblProfessor values ('Pro03', 'Paulo', 3, 'MAT01');
insert into tblProfessor values ('Pro04', 'Gabriel' , 2, 'MAT01');
go
create table tblProfTurma
(
	anoSem integer ,
	codDepto char(8),
	numDisc char(10),
	siglaTur char(5),
	codProf char(5),
	primary key (anoSem, codDepto, numDisc, siglaTur, codProf),
	foreign key (anoSem, codDepto, numDisc, siglaTur) references tblTurma,
	foreign key (codProf) references tblProfessor
);
go
insert into tblProfTurma values (20021, 'INF01','DIS01','TUR01','Pro01');
insert into tblProfTurma values (20022, 'INF01','DIS01','TUR01','Pro01');
insert into tblProfTurma values (20021, 'INF01','DIS02','TUR02','Pro02');
insert into tblProfTurma values (20021, 'MAT01','DIS01','TUR01','Pro03');
insert into tblProfTurma values (20021, 'MAT01','DIS01','TUR01','Pro02');
 select * from tblTurma