﻿
namespace ExeBD_26_10
{
    partial class FrmProdutos
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.BtnListar = new System.Windows.Forms.Button();
            this.BtnExcluir = new System.Windows.Forms.Button();
            this.BtnEditar = new System.Windows.Forms.Button();
            this.BtnGravar = new System.Windows.Forms.Button();
            this.BtnNovo = new System.Windows.Forms.Button();
            this.GrpNavegacao = new System.Windows.Forms.GroupBox();
            this.BtnUltimo = new System.Windows.Forms.Button();
            this.BtnProximo = new System.Windows.Forms.Button();
            this.BtnAnterior = new System.Windows.Forms.Button();
            this.BtnPrimeiro = new System.Windows.Forms.Button();
            this.GrpDados = new System.Windows.Forms.GroupBox();
            this.TxtValorUnitario = new System.Windows.Forms.TextBox();
            this.TxtQtdeMaxima = new System.Windows.Forms.TextBox();
            this.TxtQtdeMinima = new System.Windows.Forms.TextBox();
            this.TxtQtdeEstoque = new System.Windows.Forms.TextBox();
            this.CboRazaoSocial = new System.Windows.Forms.ComboBox();
            this.TxtDescProd = new System.Windows.Forms.TextBox();
            this.TxtCodProd = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox3.SuspendLayout();
            this.GrpNavegacao.SuspendLayout();
            this.GrpDados.SuspendLayout();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Black;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(786, 534);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(190, 96);
            this.button2.TabIndex = 10;
            this.button2.Text = "&FECHAR";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.groupBox3.Controls.Add(this.BtnListar);
            this.groupBox3.Controls.Add(this.BtnExcluir);
            this.groupBox3.Controls.Add(this.BtnEditar);
            this.groupBox3.Controls.Add(this.BtnGravar);
            this.groupBox3.Controls.Add(this.BtnNovo);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(776, 101);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(200, 414);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Operações";
            // 
            // BtnListar
            // 
            this.BtnListar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.BtnListar.Location = new System.Drawing.Point(20, 342);
            this.BtnListar.Name = "BtnListar";
            this.BtnListar.Size = new System.Drawing.Size(159, 47);
            this.BtnListar.TabIndex = 5;
            this.BtnListar.Text = "&LISTAR";
            this.BtnListar.UseVisualStyleBackColor = false;
            // 
            // BtnExcluir
            // 
            this.BtnExcluir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.BtnExcluir.Location = new System.Drawing.Point(20, 263);
            this.BtnExcluir.Name = "BtnExcluir";
            this.BtnExcluir.Size = new System.Drawing.Size(159, 47);
            this.BtnExcluir.TabIndex = 4;
            this.BtnExcluir.Text = "E&XCLUIR";
            this.BtnExcluir.UseVisualStyleBackColor = false;
            // 
            // BtnEditar
            // 
            this.BtnEditar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.BtnEditar.Location = new System.Drawing.Point(20, 188);
            this.BtnEditar.Name = "BtnEditar";
            this.BtnEditar.Size = new System.Drawing.Size(159, 47);
            this.BtnEditar.TabIndex = 3;
            this.BtnEditar.Text = "&EDITAR";
            this.BtnEditar.UseVisualStyleBackColor = false;
            // 
            // BtnGravar
            // 
            this.BtnGravar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.BtnGravar.Enabled = false;
            this.BtnGravar.Location = new System.Drawing.Point(20, 113);
            this.BtnGravar.Name = "BtnGravar";
            this.BtnGravar.Size = new System.Drawing.Size(159, 47);
            this.BtnGravar.TabIndex = 2;
            this.BtnGravar.Text = "&GRAVAR";
            this.BtnGravar.UseVisualStyleBackColor = false;
            // 
            // BtnNovo
            // 
            this.BtnNovo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.BtnNovo.Location = new System.Drawing.Point(20, 47);
            this.BtnNovo.Name = "BtnNovo";
            this.BtnNovo.Size = new System.Drawing.Size(159, 47);
            this.BtnNovo.TabIndex = 1;
            this.BtnNovo.Text = "&NOVO";
            this.BtnNovo.UseVisualStyleBackColor = false;
            // 
            // GrpNavegacao
            // 
            this.GrpNavegacao.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.GrpNavegacao.Controls.Add(this.BtnUltimo);
            this.GrpNavegacao.Controls.Add(this.BtnProximo);
            this.GrpNavegacao.Controls.Add(this.BtnAnterior);
            this.GrpNavegacao.Controls.Add(this.BtnPrimeiro);
            this.GrpNavegacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GrpNavegacao.Location = new System.Drawing.Point(20, 534);
            this.GrpNavegacao.Name = "GrpNavegacao";
            this.GrpNavegacao.Size = new System.Drawing.Size(739, 105);
            this.GrpNavegacao.TabIndex = 8;
            this.GrpNavegacao.TabStop = false;
            this.GrpNavegacao.Text = "Navegação";
            // 
            // BtnUltimo
            // 
            this.BtnUltimo.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnUltimo.Location = new System.Drawing.Point(613, 33);
            this.BtnUltimo.Name = "BtnUltimo";
            this.BtnUltimo.Size = new System.Drawing.Size(71, 63);
            this.BtnUltimo.TabIndex = 3;
            this.BtnUltimo.Text = ">|";
            this.BtnUltimo.UseVisualStyleBackColor = true;
            // 
            // BtnProximo
            // 
            this.BtnProximo.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnProximo.Location = new System.Drawing.Point(456, 33);
            this.BtnProximo.Name = "BtnProximo";
            this.BtnProximo.Size = new System.Drawing.Size(71, 63);
            this.BtnProximo.TabIndex = 2;
            this.BtnProximo.Text = ">";
            this.BtnProximo.UseVisualStyleBackColor = true;
            // 
            // BtnAnterior
            // 
            this.BtnAnterior.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAnterior.Location = new System.Drawing.Point(296, 33);
            this.BtnAnterior.Name = "BtnAnterior";
            this.BtnAnterior.Size = new System.Drawing.Size(71, 63);
            this.BtnAnterior.TabIndex = 1;
            this.BtnAnterior.Text = "<";
            this.BtnAnterior.UseVisualStyleBackColor = true;
            // 
            // BtnPrimeiro
            // 
            this.BtnPrimeiro.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnPrimeiro.Location = new System.Drawing.Point(148, 33);
            this.BtnPrimeiro.Name = "BtnPrimeiro";
            this.BtnPrimeiro.Size = new System.Drawing.Size(71, 63);
            this.BtnPrimeiro.TabIndex = 0;
            this.BtnPrimeiro.Text = "|<";
            this.BtnPrimeiro.UseVisualStyleBackColor = true;
            // 
            // GrpDados
            // 
            this.GrpDados.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.GrpDados.Controls.Add(this.TxtValorUnitario);
            this.GrpDados.Controls.Add(this.TxtQtdeMaxima);
            this.GrpDados.Controls.Add(this.TxtQtdeMinima);
            this.GrpDados.Controls.Add(this.TxtQtdeEstoque);
            this.GrpDados.Controls.Add(this.CboRazaoSocial);
            this.GrpDados.Controls.Add(this.TxtDescProd);
            this.GrpDados.Controls.Add(this.TxtCodProd);
            this.GrpDados.Controls.Add(this.label9);
            this.GrpDados.Controls.Add(this.label8);
            this.GrpDados.Controls.Add(this.label7);
            this.GrpDados.Controls.Add(this.label6);
            this.GrpDados.Controls.Add(this.label5);
            this.GrpDados.Controls.Add(this.label4);
            this.GrpDados.Controls.Add(this.label3);
            this.GrpDados.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GrpDados.Location = new System.Drawing.Point(20, 101);
            this.GrpDados.Name = "GrpDados";
            this.GrpDados.Size = new System.Drawing.Size(739, 414);
            this.GrpDados.TabIndex = 7;
            this.GrpDados.TabStop = false;
            this.GrpDados.Text = "Dados Cadastrais";
            // 
            // TxtValorUnitario
            // 
            this.TxtValorUnitario.Enabled = false;
            this.TxtValorUnitario.Location = new System.Drawing.Point(282, 342);
            this.TxtValorUnitario.MaxLength = 10;
            this.TxtValorUnitario.Name = "TxtValorUnitario";
            this.TxtValorUnitario.Size = new System.Drawing.Size(209, 34);
            this.TxtValorUnitario.TabIndex = 6;
            // 
            // TxtQtdeMaxima
            // 
            this.TxtQtdeMaxima.Enabled = false;
            this.TxtQtdeMaxima.Location = new System.Drawing.Point(282, 299);
            this.TxtQtdeMaxima.MaxLength = 5;
            this.TxtQtdeMaxima.Name = "TxtQtdeMaxima";
            this.TxtQtdeMaxima.Size = new System.Drawing.Size(153, 34);
            this.TxtQtdeMaxima.TabIndex = 5;
            // 
            // TxtQtdeMinima
            // 
            this.TxtQtdeMinima.Enabled = false;
            this.TxtQtdeMinima.Location = new System.Drawing.Point(284, 253);
            this.TxtQtdeMinima.MaxLength = 5;
            this.TxtQtdeMinima.Name = "TxtQtdeMinima";
            this.TxtQtdeMinima.Size = new System.Drawing.Size(153, 34);
            this.TxtQtdeMinima.TabIndex = 4;
            // 
            // TxtQtdeEstoque
            // 
            this.TxtQtdeEstoque.Enabled = false;
            this.TxtQtdeEstoque.Location = new System.Drawing.Point(284, 206);
            this.TxtQtdeEstoque.MaxLength = 5;
            this.TxtQtdeEstoque.Name = "TxtQtdeEstoque";
            this.TxtQtdeEstoque.Size = new System.Drawing.Size(153, 34);
            this.TxtQtdeEstoque.TabIndex = 3;
            // 
            // CboRazaoSocial
            // 
            this.CboRazaoSocial.DisplayMember = "RazaoSocial";
            this.CboRazaoSocial.Enabled = false;
            this.CboRazaoSocial.FormattingEnabled = true;
            this.CboRazaoSocial.Location = new System.Drawing.Point(284, 159);
            this.CboRazaoSocial.Name = "CboRazaoSocial";
            this.CboRazaoSocial.Size = new System.Drawing.Size(438, 37);
            this.CboRazaoSocial.TabIndex = 3;
            this.CboRazaoSocial.ValueMember = "CodFornec";
            // 
            // TxtDescProd
            // 
            this.TxtDescProd.Enabled = false;
            this.TxtDescProd.Location = new System.Drawing.Point(282, 113);
            this.TxtDescProd.MaxLength = 50;
            this.TxtDescProd.Name = "TxtDescProd";
            this.TxtDescProd.Size = new System.Drawing.Size(440, 34);
            this.TxtDescProd.TabIndex = 1;
            // 
            // TxtCodProd
            // 
            this.TxtCodProd.Enabled = false;
            this.TxtCodProd.Location = new System.Drawing.Point(282, 60);
            this.TxtCodProd.MaxLength = 5;
            this.TxtCodProd.Name = "TxtCodProd";
            this.TxtCodProd.Size = new System.Drawing.Size(153, 34);
            this.TxtCodProd.TabIndex = 0;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(19, 342);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(200, 29);
            this.label9.TabIndex = 6;
            this.label9.Text = "Valor Unitário R$:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(19, 299);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(233, 29);
            this.label8.TabIndex = 5;
            this.label8.Text = "Quantidade Máxima:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(19, 253);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(228, 29);
            this.label7.TabIndex = 4;
            this.label7.Text = "Quantidade Mínima:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 206);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(239, 29);
            this.label6.TabIndex = 3;
            this.label6.Text = "Quantidade Estoque:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 162);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(251, 29);
            this.label5.TabIndex = 2;
            this.label5.Text = "Nome do Fornecedor:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 113);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(252, 29);
            this.label4.TabIndex = 1;
            this.label4.Text = "Descrição do Produto:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(223, 29);
            this.label3.TabIndex = 0;
            this.label3.Text = "Codigo do Produto:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(310, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(383, 32);
            this.label2.TabIndex = 6;
            this.label2.Text = "CADASTRO DE PRODUTOS";
            // 
            // FrmProdutos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(999, 677);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.GrpNavegacao);
            this.Controls.Add(this.GrpDados);
            this.Controls.Add(this.label2);
            this.MaximizeBox = false;
            this.Name = "FrmProdutos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cadastro de Produtos";
            this.groupBox3.ResumeLayout(false);
            this.GrpNavegacao.ResumeLayout(false);
            this.GrpDados.ResumeLayout(false);
            this.GrpDados.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button BtnListar;
        private System.Windows.Forms.Button BtnExcluir;
        private System.Windows.Forms.Button BtnEditar;
        private System.Windows.Forms.Button BtnGravar;
        private System.Windows.Forms.Button BtnNovo;
        private System.Windows.Forms.GroupBox GrpNavegacao;
        private System.Windows.Forms.Button BtnUltimo;
        private System.Windows.Forms.Button BtnProximo;
        private System.Windows.Forms.Button BtnAnterior;
        private System.Windows.Forms.Button BtnPrimeiro;
        private System.Windows.Forms.GroupBox GrpDados;
        private System.Windows.Forms.TextBox TxtValorUnitario;
        private System.Windows.Forms.TextBox TxtQtdeMaxima;
        private System.Windows.Forms.TextBox TxtQtdeMinima;
        private System.Windows.Forms.TextBox TxtQtdeEstoque;
        private System.Windows.Forms.ComboBox CboRazaoSocial;
        private System.Windows.Forms.TextBox TxtDescProd;
        private System.Windows.Forms.TextBox TxtCodProd;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
    }
}

